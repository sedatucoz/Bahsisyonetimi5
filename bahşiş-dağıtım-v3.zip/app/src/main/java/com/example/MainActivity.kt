package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material.icons.filled.SettingsBackupRestore
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.collectLatest
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.FirebaseApp
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Request
import okhttp3.OkHttpClient
import org.json.JSONObject
import org.json.JSONArray

// Personnel Data Class with state properties
class Personel(
    val id: String,
    initialName: String,
    initialPuan: Double,
    initialActive: Boolean = true
) {
    var ad by mutableStateOf(initialName)
    var puanInput by mutableStateOf(initialPuan.toString())
    var calistiMi by mutableStateOf(initialActive)

    val puan: Double
        get() = puanInput.replace(',', '.').toDoubleOrNull() ?: 0.0
}

class KesintiKategori(
    val id: String,
    initialName: String,
    initialPercentage: Double
) {
    var adi by mutableStateOf(initialName)
    var yuzdeInput by mutableStateOf(initialPercentage.toString())

    val yuzde: Double
        get() = yuzdeInput.replace(',', '.').toDoubleOrNull() ?: 0.0
}

// Day Data Class to track Tip inputs and attendance for that specific day
class GunVeri(val adi: String) {
    var nakit by mutableStateOf("")
    var kart by mutableStateOf("")
    val calisanlar = mutableStateMapOf<String, Boolean>()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            FirebaseApp.initializeApp(this)
        } catch (t: Throwable) {
            t.printStackTrace()
        }
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme(dynamicColor = false) {
                BahsisHesaplayiciApp()
            }
        }
    }
}

// OkHttpClient instance for lightweight REST backup/restore operations
val okHttpClient = OkHttpClient()

fun String.escapeJson(): String {
    return this.replace("\\", "\\\\")
               .replace("\"", "\\\"")
               .replace("\n", "\\n")
               .replace("\r", "\\r")
               .replace("\t", "\\t")
}

fun serializeStateToJson(
    personeller: List<Personel>,
    gunVerileri: List<GunVeri>,
    kesintiler: List<KesintiKategori>,
    cardCommissionInput: String
): String {
    val sb = StringBuilder()
    sb.append("{")
    
    // 1. Card Commission
    sb.append("\"card_commission_pct\":\"${cardCommissionInput.escapeJson()}\",")
    
    // 2. Personeller
    sb.append("\"personeller\":[")
    personeller.forEachIndexed { index, p ->
        sb.append("{")
        sb.append("\"id\":\"${p.id.escapeJson()}\",")
        sb.append("\"ad\":\"${p.ad.escapeJson()}\",")
        sb.append("\"puanInput\":\"${p.puanInput.escapeJson()}\"")
        sb.append("}")
        if (index < personeller.size - 1) sb.append(",")
    }
    sb.append("],")
    
    // 3. Kesintiler
    sb.append("\"kesintiler\":[")
    kesintiler.forEachIndexed { index, k ->
        sb.append("{")
        sb.append("\"id\":\"${k.id.escapeJson()}\",")
        sb.append("\"adi\":\"${k.adi.escapeJson()}\",")
        sb.append("\"yuzdeInput\":\"${k.yuzdeInput.escapeJson()}\"")
        sb.append("}")
        if (index < kesintiler.size - 1) sb.append(",")
    }
    sb.append("],")
    
    // 4. GunVerileri
    sb.append("\"gunler\":[")
    gunVerileri.forEachIndexed { index, g ->
        sb.append("{")
        sb.append("\"nakit\":\"${g.nakit.escapeJson()}\",")
        sb.append("\"kart\":\"${g.kart.escapeJson()}\",")
        sb.append("\"calisanlar\":{")
        val activeEntries = g.calisanlar.entries.toList()
        activeEntries.forEachIndexed { eIndex, entry ->
            sb.append("\"${entry.key.escapeJson()}\":${entry.value}")
            if (eIndex < activeEntries.size - 1) sb.append(",")
        }
        sb.append("}")
        sb.append("}")
        if (index < gunVerileri.size - 1) sb.append(",")
    }
    sb.append("],")
    
    // 5. Timestamp
    sb.append("\"timestamp\":${System.currentTimeMillis()}")
    
    sb.append("}")
    return sb.toString()
}

fun loadStateFromJson(
    jsonStr: String,
    personeller: SnapshotStateList<Personel>,
    gunVerileri: List<GunVeri>,
    kesintiler: SnapshotStateList<KesintiKategori>
): String? {
    try {
        val root = JSONObject(jsonStr)
        
        // 1. Parse Personeller
        if (root.has("personeller")) {
            val pArray = root.getJSONArray("personeller")
            personeller.clear()
            for (i in 0 until pArray.length()) {
                val pObj = pArray.getJSONObject(i)
                val id = pObj.optString("id", java.util.UUID.randomUUID().toString())
                val ad = pObj.optString("ad", "")
                val puanInput = pObj.optString("puanInput", "1.0")
                
                val pVal = puanInput.replace(',', '.').toDoubleOrNull() ?: 1.0
                personeller.add(Personel(id, ad, pVal).apply {
                    this.puanInput = puanInput
                })
            }
        }
        
        // 2. Parse Kesintiler
        if (root.has("kesintiler")) {
            val kArray = root.getJSONArray("kesintiler")
            kesintiler.clear()
            for (i in 0 until kArray.length()) {
                val kObj = kArray.getJSONObject(i)
                val id = kObj.optString("id", java.util.UUID.randomUUID().toString())
                val adi = kObj.optString("adi", "")
                val yuzdeInput = kObj.optString("yuzdeInput", "0.0")
                
                val pVal = yuzdeInput.replace(',', '.').toDoubleOrNull() ?: 0.0
                kesintiler.add(KesintiKategori(id, adi, pVal).apply {
                    this.yuzdeInput = yuzdeInput
                })
            }
        }
        
        // 3. Parse Gunler
        if (root.has("gunler")) {
            val gArray = root.getJSONArray("gunler")
            for (i in 0 until minOf(gArray.length(), gunVerileri.size)) {
                val gObj = gArray.getJSONObject(i)
                val g = gunVerileri[i]
                g.nakit = gObj.optString("nakit", "")
                g.kart = gObj.optString("kart", "")
                
                g.calisanlar.clear()
                if (gObj.has("calisanlar")) {
                    val calisanlarObj = gObj.getJSONObject("calisanlar")
                    val keys = calisanlarObj.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        val value = calisanlarObj.getBoolean(key)
                        g.calisanlar[key] = value
                    }
                }
            }
        }
        
        return root.optString("card_commission_pct", "12")
    } catch (e: Throwable) {
        android.util.Log.e("BahsisBackup", "Failed to parse JSON backup", e)
        return null
    }
}

// Safe mathematical rounding to handle infinity or extreme user input gracefully without crashes
fun Double.safeRoundToInt(): Int {
    if (this.isNaN() || this.isInfinite()) return 0
    if (this > Int.MAX_VALUE.toDouble()) return Int.MAX_VALUE
    if (this < Int.MIN_VALUE.toDouble()) return Int.MIN_VALUE
    return this.roundToInt()
}

// Thread-safe data transfer objects for SharedPreferences serialization
class PersonelData(val id: String, val ad: String, val puanInput: String)
class GunVeriData(val nakit: String, val kart: String, val calisanlar: Map<String, Boolean>)
class KesintiKategoriData(val id: String, val adi: String, val yuzdeInput: String)

// SharedPreferences State persistence helpers to retain results between sessions safely
fun ipucuKaydet(
    context: android.content.Context,
    personeller: List<PersonelData>,
    gunler: List<GunVeriData>,
    kesintiler: List<KesintiKategoriData>
) {
    val prefs = context.getSharedPreferences("bahsis_prefs_v3", android.content.Context.MODE_PRIVATE)
    val editor = prefs.edit()
    
    // Save personnel IDs
    val idsStr = personeller.joinToString(",") { it.id }
    editor.putString("personel_ids", idsStr)
    
    personeller.forEach { p ->
        editor.putString("name_${p.id}", p.ad)
        editor.putString("puan_${p.id}", p.puanInput)
    }
    
    // Save each day's values
    gunler.forEachIndexed { idx, v ->
        editor.putString("day_nakit_$idx", v.nakit)
        editor.putString("day_kart_$idx", v.kart)
        // Store attendance mappings by ID
        personeller.forEach { p ->
            editor.putBoolean("day_active_${idx}_${p.id}", v.calisanlar[p.id] ?: true)
        }
    }

    // Save deduction categories
    val kesintiIds = kesintiler.joinToString(",") { it.id }
    editor.putString("kesinti_ids", kesintiIds)
    kesintiler.forEach { k ->
        editor.putString("kesinti_name_${k.id}", k.adi)
        editor.putString("kesinti_yuzde_${k.id}", k.yuzdeInput)
    }

    editor.apply()
}

fun ipucuYukle(
    context: android.content.Context,
    personeller: SnapshotStateList<Personel>,
    gunler: List<GunVeri>,
    kesintiler: SnapshotStateList<KesintiKategori>
) {
    val prefs = context.getSharedPreferences("bahsis_prefs_v3", android.content.Context.MODE_PRIVATE)
    try {
        val idsStr = prefs.getString("personel_ids", null)
        
        personeller.clear()
        if (idsStr != null) {
            val ids = idsStr.split(",").filter { it.isNotBlank() }.distinct()
            ids.forEach { id ->
                val name = prefs.getString("name_$id", "") ?: ""
                val points = prefs.getString("puan_$id", "1.00") ?: "1.00"
                personeller.add(Personel(id, name, points.replace(',', '.').toDoubleOrNull() ?: 1.0).apply {
                    puanInput = points
                })
            }
        } else {
            val oldNamesStr = prefs.getString("personel_names", null)
            if (oldNamesStr != null) {
                val names = oldNamesStr.split(",").filter { it.isNotBlank() }.distinct()
                names.forEach { name ->
                    val points = prefs.getString("puan_$name", "1.00") ?: "1.00"
                    personeller.add(Personel(name, name, points.replace(',', '.').toDoubleOrNull() ?: 1.0).apply {
                        puanInput = points
                    })
                }
            } else {
                // Fallback to the standard starting roster specified by user
                personeller.addAll(
                    listOf(
                        Personel("cem_id", "Cem", 1.22),
                        Personel("sedat_id", "Sedat", 1.0),
                        Personel("hasan_id", "Hasan", 1.0),
                        Personel("onur_id", "Onur", 0.44),
                        Personel("nergiz_id", "Nergiz", 1.0),
                        Personel("izzettin_id", "İzzettin", 1.0)
                    )
                )
            }
        }
        
        gunler.forEachIndexed { idx, v ->
            v.nakit = prefs.getString("day_nakit_$idx", "") ?: ""
            v.kart = prefs.getString("day_kart_$idx", "") ?: ""
            personeller.forEach { p ->
                val newKey = "day_active_${idx}_${p.id}"
                if (prefs.contains(newKey)) {
                    v.calisanlar[p.id] = prefs.getBoolean(newKey, true)
                } else {
                    v.calisanlar[p.id] = prefs.getBoolean("day_active_${idx}_${p.ad}", true)
                }
            }
        }

        // Load deduction categories
        val kesintiIdsStr = prefs.getString("kesinti_ids", null)
        kesintiler.clear()
        if (kesintiIdsStr != null) {
            val ids = kesintiIdsStr.split(",").filter { it.isNotBlank() }.distinct()
            ids.forEach { id ->
                val name = prefs.getString("kesinti_name_$id", "") ?: ""
                val yuzde = prefs.getString("kesinti_yuzde_$id", "0.0") ?: "0.0"
                kesintiler.add(KesintiKategori(id, name, yuzde.replace(',', '.').toDoubleOrNull() ?: 0.0).apply {
                    yuzdeInput = yuzde
                })
            }
        } else {
            // Defaults
            kesintiler.addAll(
                listOf(
                    KesintiKategori("mutfak_id", "Mutfak", 15.0),
                    KesintiKategori("bulasikhane_id", "Bulaşıkhane", 5.0)
                )
            )
        }

    } catch (e: Throwable) {
        android.util.Log.e("BahsisApp", "Failed to load preferences, using fallback roster", e)
        personeller.clear()
        personeller.addAll(
            listOf(
                Personel("cem_id", "Cem", 1.22),
                Personel("sedat_id", "Sedat", 1.0),
                Personel("hasan_id", "Hasan", 1.0),
                Personel("onur_id", "Onur", 0.44),
                Personel("nergiz_id", "Nergiz", 1.0),
                Personel("izzettin_id", "İzzettin", 1.0)
            )
        )
        gunler.forEach { v ->
            v.nakit = ""
            v.kart = ""
            v.calisanlar.clear()
            personeller.forEach { p ->
                v.calisanlar[p.id] = true
            }
        }
        kesintiler.clear()
        kesintiler.addAll(
            listOf(
                KesintiKategori("mutfak_id", "Mutfak", 15.0),
                KesintiKategori("bulasikhane_id", "Bulaşıkhane", 5.0)
            )
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BahsisHesaplayiciApp() {
    val originalContext = LocalContext.current
    val originalPrefs = remember { originalContext.getSharedPreferences("bahsis_prefs_v3", android.content.Context.MODE_PRIVATE) }
    
    val initialLang = remember {
        val saved = originalPrefs.getString("selected_lang", null)
        if (saved != null) {
            saved
        } else {
            val sysLocale = java.util.Locale.getDefault()
            val isTr = sysLocale.language == "tr" || sysLocale.country == "TR"
            if (isTr) "tr" else "en"
        }
    }
    
    var appLanguage by remember { mutableStateOf(initialLang) }
    
    val localizedContext = remember(appLanguage) {
        val locale = java.util.Locale(appLanguage)
        java.util.Locale.setDefault(locale)
        val config = android.content.res.Configuration(originalContext.resources.configuration)
        config.setLocale(locale)
        originalContext.createConfigurationContext(config)
    }

    CompositionLocalProvider(
        LocalContext provides localizedContext
    ) {
        key(appLanguage) {
        val context = LocalContext.current
        val prefs = remember(context) { context.getSharedPreferences("bahsis_prefs_v3", android.content.Context.MODE_PRIVATE) }
        
        var showDialog by remember { mutableStateOf(false) }
        var showResetDialog by remember { mutableStateOf(false) }
        var showGuideDialog by remember { mutableStateOf(false) }
        var showContactDialog by remember { mutableStateOf(false) }
        var showMenu by remember { mutableStateOf(false) }
        val saveFlow = remember { MutableSharedFlow<Unit>(extraBufferCapacity = 1) }
        val triggerSave = remember(saveFlow) { { saveFlow.tryEmit(Unit); Unit } }

        // Colors aligned with the "Frosted Glass" design theme spec
    val primaryGreen = Color(0xFF386B01)
    val textPrimary = Color(0xFF1A1C19)
    val textSecondary = Color(0xFF43493E)
    val bgGreenLight = Color(0xFFF7FBF2)
    val glassBg = Color(0xFFE1E9D7).copy(alpha = 0.6f)
    val borderLight = Color(0xFFE1E9D7)
    val borderMuted = Color(0xFFC1C9B7)
    val inputBorderColor = Color(0xFF74796D)

    // Initial List of personnel (will be loaded on launch)
    val personeller = remember { mutableStateListOf<Personel>() }
    val kesintiler = remember { mutableStateListOf<KesintiKategori>() }
    var cardCommissionInput by remember { mutableStateOf("12") }

    val mondayStr = stringResource(R.string.monday)
    val tuesdayStr = stringResource(R.string.tuesday)
    val wednesdayStr = stringResource(R.string.wednesday)
    val thursdayStr = stringResource(R.string.thursday)
    val fridayStr = stringResource(R.string.friday)
    val saturdayStr = stringResource(R.string.saturday)
    val sundayStr = stringResource(R.string.sunday)

    // Standard days of the week list
    val gunlerList = remember(mondayStr, tuesdayStr, wednesdayStr, thursdayStr, fridayStr, saturdayStr, sundayStr) {
        listOf(mondayStr, tuesdayStr, wednesdayStr, thursdayStr, fridayStr, saturdayStr, sundayStr)
    }

    // Days representation data structures
    val gunVerileri = remember {
        mutableStateListOf<GunVeri>().apply {
            if (isEmpty()) {
                gunlerList.forEach { name ->
                    add(GunVeri(name))
                }
            }
        }
    }

    // Load persisted state on mount
    var hasLoaded by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        try {
            val prefs = context.getSharedPreferences("bahsis_prefs_v3", android.content.Context.MODE_PRIVATE)
            try {
                cardCommissionInput = prefs.getString("card_commission_pct", "12") ?: "12"
            } catch (ce: Exception) {
                cardCommissionInput = "12"
            }
            ipucuYukle(context, personeller, gunVerileri, kesintiler)
        } catch (t: Throwable) {
            android.util.Log.e("BahsisApp", "Fatal error during startup data load", t)
        } finally {
            hasLoaded = true
        }
    }

    // Highly robust debounced auto-save system:
    // Saves 1 second after last edit trigger to prevent UI lag, excessive serialization, and concurrent access crashes
    LaunchedEffect(saveFlow) {
        saveFlow.collectLatest {
            if (hasLoaded) {
                delay(1000) // Debounce for 1 second of inactivity
                try {
                    val personellerCopy = personeller.toList().map { PersonelData(it.id, it.ad, it.puanInput) }
                    val gunlerCopy = gunVerileri.toList().map { g ->
                        GunVeriData(g.nakit, g.kart, g.calisanlar.toMap())
                    }
                    val kesintilerCopy = kesintiler.toList().map { KesintiKategoriData(it.id, it.adi, it.yuzdeInput) }
                    val cardCommissionCopy = cardCommissionInput
                    
                    // Compute JSON backup payload safely on the Main thread to avoid Snapshot State / Threading race exceptions
                    val payload = serializeStateToJson(personeller, gunVerileri, kesintiler, cardCommissionCopy)
                    
                    // Ensure saving completes even if typing continues and cancels the outer LaunchedEffect
                    withContext(kotlinx.coroutines.NonCancellable + Dispatchers.IO) {
                        ipucuKaydet(context, personellerCopy, gunlerCopy, kesintilerCopy)
                        val prefs = context.getSharedPreferences("bahsis_prefs_v3", android.content.Context.MODE_PRIVATE)
                        prefs.edit().putString("card_commission_pct", cardCommissionCopy).apply()

                        // Cloud Auto-Sync if signed in
                        val extEmail = prefs.getString("google_signed_in_email", null)
                        if (extEmail != null) {
                            try {
                                val sEmail = extEmail.replace(".", "_").replace("@", "_")
                                val url = "https://bahsis-v3-default-rtdb.europe-west1.firebasedatabase.app/backups/$sEmail.json"
                                val mType = "application/json; charset=utf-8".toMediaType()
                                val reqBody = payload.toRequestBody(mType)
                                val req = Request.Builder().url(url).put(reqBody).build()
                                val response = okHttpClient.newCall(req).execute()
                                if (response.isSuccessful) {
                                    prefs.edit().putLong("last_cloud_sync_time", System.currentTimeMillis()).apply()
                                }
                                response.close()
                            } catch (e: Throwable) {
                                android.util.Log.e("BahsisBackup", "Background auto cloud sync failed", e)
                            }
                        }
                    }
                } catch (ce: kotlinx.coroutines.CancellationException) {
                    // Must always rethrow CancellationException so the coroutine framework cancels properly
                    throw ce
                } catch (e: Throwable) {
                    android.util.Log.e("BahsisApp", "Auto-save failed safely", e)
                }
            }
        }
    }

    // Selected tab: 0-6 represent weekdays, index 7 is the "Haftalık Özet" summary report
    var currentTab by remember { mutableStateOf(0) }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { 
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(context.getString(R.string.title_tip_distribution), fontWeight = FontWeight.SemiBold, fontSize = 18.sp, letterSpacing = 0.5.sp)
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = primaryGreen,
                    titleContentColor = Color.White
                ),
                actions = {
                    Box {
                        IconButton(
                            onClick = { showMenu = true }
                        ) {
                            Icon(
                                imageVector = Icons.Default.MoreVert, 
                                contentDescription = null, 
                                tint = Color.White
                            )
                        }
                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false }
                        ) {
                            DropdownMenuItem(
                                leadingIcon = { Icon(Icons.Default.SettingsBackupRestore, contentDescription = null, tint = primaryGreen) },
                                text = { Text(context.getString(R.string.menu_cloud_backup), fontWeight = FontWeight.Medium) },
                                onClick = {
                                    currentTab = 9
                                    showMenu = false
                                }
                            )
                            DropdownMenuItem(
                                leadingIcon = { Icon(Icons.Default.Settings, contentDescription = null, tint = primaryGreen) },
                                text = { Text(context.getString(R.string.menu_deductions), fontWeight = FontWeight.Medium) },
                                onClick = {
                                    currentTab = 8
                                    showMenu = false
                                }
                            )
                            DropdownMenuItem(
                                leadingIcon = { Icon(Icons.Default.Percent, contentDescription = null, tint = primaryGreen) },
                                text = { Text(context.getString(R.string.menu_weekly_summary), fontWeight = FontWeight.Medium) },
                                onClick = {
                                    currentTab = 7
                                    showMenu = false
                                }
                            )
                            DropdownMenuItem(
                                leadingIcon = { Icon(Icons.Default.Translate, contentDescription = null, tint = primaryGreen) },
                                text = { Text(context.getString(R.string.menu_language), fontWeight = FontWeight.Medium) },
                                onClick = {
                                    currentTab = 10
                                    showMenu = false
                                }
                            )
                            HorizontalDivider(color = borderMuted.copy(alpha = 0.5f))
                            DropdownMenuItem(
                                leadingIcon = { Icon(Icons.Default.Info, contentDescription = null, tint = primaryGreen) },
                                text = { Text(context.getString(R.string.menu_user_guide), fontWeight = FontWeight.Medium) },
                                onClick = {
                                    showGuideDialog = true
                                    showMenu = false
                                }
                            )
                            DropdownMenuItem(
                                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = primaryGreen) },
                                text = { Text(context.getString(R.string.menu_support), fontWeight = FontWeight.Medium) },
                                onClick = {
                                    showContactDialog = true
                                    showMenu = false
                                }
                            )
                            HorizontalDivider(color = borderMuted.copy(alpha = 0.5f))
                            DropdownMenuItem(
                                leadingIcon = { Icon(Icons.Default.Refresh, contentDescription = null, tint = Color(0xFFC62828)) },
                                text = { Text(context.getString(R.string.menu_reset_week), fontWeight = FontWeight.Bold, color = Color(0xFFC62828)) },
                                onClick = {
                                    showResetDialog = true
                                    showMenu = false
                                }
                            )
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            if (currentTab != 9 && currentTab != 10) {
                FloatingActionButton(
                    onClick = { showDialog = true },
                    containerColor = primaryGreen,
                    contentColor = Color.White,
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = stringResource(if (currentTab == 8) R.string.add_deduction_title else R.string.add_staff_title),
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .background(bgGreenLight)
        ) {
            
            // Interactive visual Day Tab Row (Monday-Sunday + Weekly Summary)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                gunlerList.forEachIndexed { index, name ->
                    val selected = currentTab == index
                    FilterChip(
                        selected = selected,
                        onClick = { currentTab = index },
                        label = { Text(name, fontSize = 13.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = primaryGreen,
                            selectedLabelColor = Color.White,
                            containerColor = Color.Transparent,
                            labelColor = textSecondary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selected,
                            borderColor = borderMuted,
                            selectedBorderColor = primaryGreen,
                            borderWidth = 1.dp
                        )
                    )
                }
                
                // Haftalık Özet Tab
                val isSummarySelected = currentTab == 7
                FilterChip(
                    selected = isSummarySelected,
                    onClick = { currentTab = 7 },
                    label = { 
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Percent, 
                                contentDescription = null, 
                                modifier = Modifier.size(14.dp),
                                tint = if (isSummarySelected) Color.White else primaryGreen
                            )
                            Text(stringResource(R.string.menu_weekly_summary)) 
                        }
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = primaryGreen,
                        selectedLabelColor = Color.White,
                        containerColor = glassBg,
                        labelColor = primaryGreen
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = isSummarySelected,
                        borderColor = borderMuted,
                        selectedBorderColor = primaryGreen,
                        borderWidth = 1.dp
                    )
                )
            }

            // Main Tab Body
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(start = 16.dp, end = 16.dp, bottom = 100.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (currentTab in 0..6) {
                    val gun = gunVerileri[currentTab]
                    
                    // Header title for the day
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.CalendarToday, contentDescription = null, tint = primaryGreen, modifier = Modifier.size(18.dp))
                        Text(
                            text = stringResource(R.string.day_tip_entry, gunlerList[currentTab]),
                            style = MaterialTheme.typography.titleMedium,
                            color = textPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Nakit ve Kart Girişleri Section Grid
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Nakit Field
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.cash_label),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = textSecondary,
                                modifier = Modifier.padding(start = 4.dp)
                            )
                            OutlinedTextField(
                                value = gun.nakit,
                                onValueChange = { input -> 
                                    gun.nakit = input
                                    triggerSave()
                                },
                                prefix = { Text("₺", color = textPrimary.copy(alpha = 0.5f), fontWeight = FontWeight.Medium) },
                                modifier = Modifier.fillMaxWidth(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = primaryGreen,
                                    unfocusedBorderColor = inputBorderColor,
                                    focusedTextColor = textPrimary,
                                    unfocusedTextColor = textPrimary,
                                    focusedContainerColor = Color.White,
                                    unfocusedContainerColor = Color.White
                                ),
                                shape = RoundedCornerShape(8.dp),
                                trailingIcon = if (gun.nakit.isNotEmpty()) {
                                    {
                                        IconButton(onClick = { 
                                            gun.nakit = ""
                                            triggerSave()
                                        }) {
                                            Icon(Icons.Default.Close, contentDescription = stringResource(R.string.clear_button), modifier = Modifier.size(16.dp))
                                        }
                                    }
                                } else null
                            )
                        }

                        // Kart Field (Displays 12% off Net Tutar beneath as requested)
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.card_label),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = textSecondary,
                                modifier = Modifier.padding(start = 4.dp)
                            )
                            OutlinedTextField(
                                value = gun.kart,
                                onValueChange = { input -> 
                                    gun.kart = input
                                    triggerSave()
                                },
                                prefix = { Text("₺", color = textPrimary.copy(alpha = 0.5f), fontWeight = FontWeight.Medium) },
                                modifier = Modifier.fillMaxWidth(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = primaryGreen,
                                    unfocusedBorderColor = inputBorderColor,
                                    focusedTextColor = textPrimary,
                                    unfocusedTextColor = textPrimary,
                                    focusedContainerColor = Color.White,
                                    unfocusedContainerColor = Color.White
                                ),
                                shape = RoundedCornerShape(8.dp),
                                trailingIcon = if (gun.kart.isNotEmpty()) {
                                    {
                                        IconButton(onClick = { 
                                            gun.kart = ""
                                            triggerSave()
                                        }) {
                                            Icon(Icons.Default.Close, contentDescription = stringResource(R.string.clear_button), modifier = Modifier.size(16.dp))
                                        }
                                    }
                                } else null
                            )
                        }
                    }

                    // Display Card Net immediately below the inputs
                    val grossKart = gun.kart.replace(',', '.').toDoubleOrNull() ?: 0.0
                    val cardCommVal = (cardCommissionInput.replace(',', '.').toDoubleOrNull() ?: 12.0).coerceIn(0.0, 100.0)
                    val computedKartNet = grossKart * (1.0 - (cardCommVal / 100.0))
                    
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.card_net_prefix),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = textSecondary
                            )
                            BasicTextField(
                                value = cardCommissionInput,
                                onValueChange = {
                                    cardCommissionInput = it
                                    triggerSave()
                                },
                                textStyle = TextStyle(
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = primaryGreen,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                ),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                singleLine = true,
                                decorationBox = { innerTextField ->
                                    Box(contentAlignment = Alignment.Center) {
                                        innerTextField()
                                    }
                                },
                                modifier = Modifier
                                    .width(42.dp)
                                    .background(Color(0xFFF1F5F9), RoundedCornerShape(4.dp))
                                    .border(1.dp, Color(0xFFD1D5DB), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                            Text(
                                text = stringResource(R.string.card_net_suffix),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = textSecondary
                            )
                        }
                        Text(
                            text = "${String.format(java.util.Locale.US, "%.2f", computedKartNet)} ₺",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = primaryGreen
                        )
                    }

                    // Calculations for active day tab
                    val dailyNakit = gun.nakit.replace(',', '.').toDoubleOrNull() ?: 0.0
                    val dailyTotal = dailyNakit + computedKartNet
                    
                    val kesintilerToplam = kesintiler.sumOf { k -> (dailyTotal * (k.yuzde / 100.0)).safeRoundToInt() }
                    val dailyKalan = dailyTotal.safeRoundToInt() - kesintilerToplam

                    val activeDayStaff = personeller.filter { p -> gun.calisanlar[p.id] ?: true }
                    val dailyTotalPoints = activeDayStaff.sumOf { it.puan }

                    // Daily Summary Card - Frosted Glass effect
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = glassBg),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.4f)),
                        elevation = CardDefaults.cardElevation(0.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = stringResource(R.string.daily_distribution_detail),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = primaryGreen,
                                    letterSpacing = 0.5.sp
                                )
                                TextButton(
                                    onClick = {
                                        val newCat = KesintiKategori(
                                            id = java.util.UUID.randomUUID().toString(),
                                            initialName = "",
                                            initialPercentage = 5.0
                                        ).apply {
                                            yuzdeInput = "5.0"
                                        }
                                        kesintiler.add(newCat)
                                        triggerSave()
                                    },
                                    contentPadding = PaddingValues(0.dp),
                                    modifier = Modifier.height(28.dp),
                                    colors = ButtonDefaults.textButtonColors(contentColor = primaryGreen)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text(stringResource(R.string.add_expense_category_btn), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            
                            OzetSatir(stringResource(R.string.net_revenue_label), "${dailyTotal.safeRoundToInt()} ₺", textSecondary, textPrimary)
                            
                            if (kesintiler.isEmpty()) {
                                Text(
                                    text = stringResource(R.string.no_deductions_placeholder),
                                    fontSize = 12.sp,
                                    color = textSecondary,
                                    modifier = Modifier.padding(vertical = 4.dp)
                                )
                            } else {
                                Column(
                                    verticalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    kesintiler.toList().forEach { k ->
                                        key(k.id) {
                                            val mValue = (dailyTotal * (k.yuzde / 100.0)).safeRoundToInt()
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                            // Name edit field with placeholder
                                            BasicTextField(
                                                value = k.adi,
                                                onValueChange = {
                                                    k.adi = it
                                                    triggerSave()
                                                },
                                                textStyle = TextStyle(
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Medium,
                                                    color = textPrimary
                                                ),
                                                decorationBox = { innerTextField ->
                                                    Box(contentAlignment = Alignment.CenterStart) {
                                                        if (k.adi.isEmpty()) {
                                                            Text(
                                                                text = stringResource(R.string.category_name_placeholder),
                                                                color = Color.Gray.copy(alpha = 0.4f),
                                                                fontSize = 11.sp
                                                            )
                                                        }
                                                        innerTextField()
                                                    }
                                                },
                                                modifier = Modifier
                                                    .weight(1.8f)
                                                    .background(Color(0xFFF8FAFC), RoundedCornerShape(6.dp))
                                                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(6.dp))
                                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                                singleLine = true
                                            )

                                            // Percentage edit field
                                            Row(
                                                modifier = Modifier
                                                    .width(62.dp)
                                                    .background(Color(0xFFF8FAFC), RoundedCornerShape(6.dp))
                                                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(6.dp))
                                                    .padding(horizontal = 6.dp, vertical = 4.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                                            ) {
                                                Text("%", fontSize = 10.sp, color = textSecondary, fontWeight = FontWeight.Bold)
                                                BasicTextField(
                                                    value = k.yuzdeInput,
                                                    onValueChange = {
                                                        k.yuzdeInput = it
                                                        triggerSave()
                                                    },
                                                    textStyle = TextStyle(
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = primaryGreen
                                                    ),
                                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                                    singleLine = true,
                                                    modifier = Modifier.fillMaxWidth()
                                                )
                                            }

                                            // Calculated amount preview
                                            Text(
                                                text = "$mValue ₺",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = textPrimary,
                                                modifier = Modifier.weight(0.9f),
                                                textAlign = androidx.compose.ui.text.style.TextAlign.End
                                            )

                                            // Direct delete button
                                            IconButton(
                                                onClick = {
                                                    kesintiler.remove(k)
                                                    triggerSave()
                                                },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Delete,
                                                    contentDescription = stringResource(R.string.delete_gider_desc),
                                                    tint = Color(0xFFD32F2F).copy(alpha = 0.8f),
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                                }
                            }
                            
                            HorizontalDivider(
                                modifier = Modifier.padding(vertical = 4.dp),
                                color = borderMuted
                            )
                            
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    stringResource(R.string.remaining_to_distribute_label),
                                    style = TextStyle(
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = primaryGreen
                                    )
                                )
                                Text(
                                    "$dailyKalan ₺",
                                    style = TextStyle(
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Black,
                                        color = primaryGreen
                                    )
                                )
                            }
                            
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(stringResource(R.string.total_shares_label), fontSize = 11.sp, color = textSecondary)
                                Text(stringResource(R.string.total_employee_points_value, dailyTotalPoints), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = textPrimary)
                            }
                        }
                    }

                    // Headers with batch options as requested: "Tum isimlerin calisip calismadigi da girilebilsin"
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            stringResource(R.string.personnel_attendance_title),
                            style = TextStyle(
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = textSecondary,
                                letterSpacing = 0.5.sp
                            )
                        )
                        Text(
                            stringResource(R.string.staff_working_count, activeDayStaff.size, personeller.size),
                            style = TextStyle(
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = primaryGreen
                            )
                        )
                    }

                    // Bulk actions for attendance entry convenience
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                personeller.forEach { p ->
                                    gun.calisanlar[p.id] = true
                                }
                                triggerSave()
                            },
                            border = BorderStroke(1.dp, borderMuted),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = primaryGreen),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.Group, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(stringResource(R.string.button_works_all), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                personeller.forEach { p ->
                                    gun.calisanlar[p.id] = false
                                }
                                triggerSave()
                            },
                            border = BorderStroke(1.dp, Color(0xFFC62828).copy(alpha = 0.3f)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFC62828)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(stringResource(R.string.button_off_all), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Daily List of Personnel
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (personeller.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    stringResource(R.string.personnel_empty_state),
                                    color = textSecondary,
                                    fontSize = 13.sp,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        } else {
                            personeller.toList().forEach { personel ->
                                key(personel.id) {
                                    val calisti = gun.calisanlar[personel.id] ?: true
                                    val dynamicDailyPay = if (calisti && dailyTotalPoints > 0) {
                                        ((dailyKalan / dailyTotalPoints) * personel.puan).safeRoundToInt()
                                    } else {
                                        0
                                    }

                                    PersonelRowCard(
                                        personel = personel,
                                        calisti = calisti,
                                        dynamicDailyPay = dynamicDailyPay,
                                        borderLight = borderLight,
                                        borderMuted = borderMuted,
                                        primaryGreen = primaryGreen,
                                        textPrimary = textPrimary,
                                        textSecondary = textSecondary,
                                        onActiveChange = { active ->
                                            gun.calisanlar[personel.id] = active
                                            triggerSave()
                                        },
                                        onDelete = {
                                            personeller.remove(personel)
                                            triggerSave()
                                        },
                                        onGlobalSaveTrigger = {
                                            triggerSave()
                                        }
                                    )
                                }
                            }
                        }
                    }
                } else if (currentTab == 7) {
                    // Weekly Summary Tab calculations
                    val cardCommVal = (cardCommissionInput.replace(',', '.').toDoubleOrNull() ?: 12.0).coerceIn(0.0, 100.0)
                    val currentCardFactor = 1.0 - (cardCommVal / 100.0)

                    val totalWeeklyNakit = gunVerileri.sumOf { it.nakit.replace(',', '.').toDoubleOrNull() ?: 0.0 }
                    val totalWeeklyKartGross = gunVerileri.sumOf { it.kart.replace(',', '.').toDoubleOrNull() ?: 0.0 }
                    val totalWeeklyKartNet = totalWeeklyKartGross * currentCardFactor
                    val totalWeeklyCiro = totalWeeklyNakit + totalWeeklyKartNet

                    val totalWeeklyKalan = gunVerileri.sumOf { gun ->
                        val top = (gun.nakit.replace(',', '.').toDoubleOrNull() ?: 0.0) + (gun.kart.replace(',', '.').toDoubleOrNull() ?: 0.0) * currentCardFactor
                        val kesintiSum = kesintiler.sumOf { k ->
                            (top * (k.yuzde / 100.0)).safeRoundToInt()
                        }
                        top.safeRoundToInt() - kesintiSum
                    }

                    // Header with aggregate info
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = primaryGreen, modifier = Modifier.size(18.dp))
                        Text(
                            text = stringResource(R.string.weekly_cumulative_report),
                            style = MaterialTheme.typography.titleMedium,
                            color = textPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Financial Metrics Card (Aggregated frosted glass styling)
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = glassBg),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OzetSatir(stringResource(R.string.weekly_gross_cash), "${totalWeeklyNakit.safeRoundToInt()} ₺", textSecondary, textPrimary)
                            OzetSatir(stringResource(R.string.weekly_gross_card), "${totalWeeklyKartGross.safeRoundToInt()} ₺", textSecondary, textPrimary)
                            OzetSatir(stringResource(R.string.weekly_net_card, "$cardCommissionInput%"), "${totalWeeklyKartNet.safeRoundToInt()} ₺", textSecondary, textPrimary)
                            
                            kesintiler.toList().forEach { k ->
                                key(k.id) {
                                    val totalWeeklyKesintiValue = gunVerileri.sumOf { gun ->
                                        val top = (gun.nakit.replace(',', '.').toDoubleOrNull() ?: 0.0) + (gun.kart.replace(',', '.').toDoubleOrNull() ?: 0.0) * currentCardFactor
                                        (top * (k.yuzde / 100.0)).safeRoundToInt()
                                    }
                                    OzetSatir(stringResource(R.string.weekly_deduction_share, k.adi, k.yuzdeInput), "$totalWeeklyKesintiValue ₺", textSecondary, textPrimary)
                                }
                            }
                            
                            HorizontalDivider(
                                modifier = Modifier.padding(vertical = 4.dp),
                                color = borderMuted
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    stringResource(R.string.net_total_to_distribute),
                                    style = TextStyle(
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = primaryGreen
                                    )
                                )
                                Text(
                                    "$totalWeeklyKalan ₺",
                                    style = TextStyle(
                                        fontSize = 22.sp,
                                        fontWeight = FontWeight.Black,
                                        color = primaryGreen
                                    )
                                )
                            }
                        }
                    }

                    // Consolidated Personnel Shares List Title
                    Text(
                        text = stringResource(R.string.weekly_payout_list_header),
                        style = TextStyle(
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = textSecondary,
                            letterSpacing = 0.5.sp
                        ),
                        modifier = Modifier.padding(start = 4.dp, end = 4.dp, top = 8.dp)
                    )

                    // Weekly Hak Ediş Card Grid List
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (personeller.isEmpty()) {
                            Text(
                                stringResource(R.string.no_staff_registered),
                                color = textSecondary,
                                modifier = Modifier.padding(12.dp)
                            )
                        } else {
                            personeller.toList().forEach { personel ->
                                key(personel.id) {
                                    // Compute total accumulated share for this employee across all 7 days
                                val weeklyAccumulatedPay = gunVerileri.sumOf { gun ->
                                    val dailyN = gun.nakit.replace(',', '.').toDoubleOrNull() ?: 0.0
                                    val dailyK = (gun.kart.replace(',', '.').toDoubleOrNull() ?: 0.0) * currentCardFactor
                                    val dailyTot = dailyN + dailyK
                                    
                                    val kesintiSum = kesintiler.sumOf { k ->
                                        (dailyTot * (k.yuzde / 100.0)).safeRoundToInt()
                                    }
                                    val k = dailyTot.safeRoundToInt() - kesintiSum
                                    
                                    val activeStaff = personeller.filter { p -> gun.calisanlar[p.id] ?: true }
                                    val actPoints = activeStaff.sumOf { it.puan }
                                    
                                    val calismeDurum = gun.calisanlar[personel.id] ?: true
                                    if (calismeDurum && actPoints > 0) {
                                        ((k / actPoints) * personel.puan).safeRoundToInt()
                                    } else {
                                        0
                                    }
                                }

                                // Count active days
                                val activeDaysWorked = gunVerileri.count { gun ->
                                    gun.calisanlar[personel.id] ?: true
                                }

                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color.White),
                                    border = BorderStroke(1.dp, borderLight)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(
                                            modifier = Modifier.weight(1f),
                                            verticalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Icon(Icons.Default.Person, contentDescription = null, tint = primaryGreen, modifier = Modifier.size(16.dp))
                                                Text(
                                                    text = personel.ad,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 15.sp,
                                                    color = textPrimary
                                                )
                                            }

                                            // Subtitle indicating active parameters and attendance statistics
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Text(
                                                    text = stringResource(R.string.days_worked_stat, activeDaysWorked),
                                                    fontSize = 11.sp,
                                                    color = primaryGreen,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                                Text(
                                                    text = stringResource(R.string.coefficient_label, personel.puanInput),
                                                    fontSize = 11.sp,
                                                    color = textSecondary
                                                )
                                            }

                                            // Compact mini attendance badges for visual clarity
                                            Row(
                                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                modifier = Modifier.padding(top = 4.dp)
                                            ) {
                                                listOf(
                                                    stringResource(R.string.short_monday),
                                                    stringResource(R.string.short_tuesday),
                                                    stringResource(R.string.short_wednesday),
                                                    stringResource(R.string.short_thursday),
                                                    stringResource(R.string.short_friday),
                                                    stringResource(R.string.short_saturday),
                                                    stringResource(R.string.short_sunday)
                                                ).forEachIndexed { dIdx, dName ->
                                                    val worked = gunVerileri[dIdx].calisanlar[personel.id] ?: true
                                                    Box(
                                                        modifier = Modifier
                                                            .background(
                                                                color = if (worked) primaryGreen.copy(alpha = 0.15f) else Color.LightGray.copy(alpha = 0.2f),
                                                                shape = RoundedCornerShape(4.dp)
                                                            )
                                                            .padding(horizontal = 4.dp, vertical = 2.dp)
                                                    ) {
                                                        Text(
                                                            text = dName,
                                                            fontSize = 9.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = if (worked) primaryGreen else Color.Gray
                                                        )
                                                    }
                                                }
                                            }
                                        }

                                        // Grand Total consolidated share label
                                        Column(
                                            horizontalAlignment = Alignment.End,
                                            verticalArrangement = Arrangement.Center
                                        ) {
                                            Text(
                                                text = "$weeklyAccumulatedPay ₺",
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 18.sp,
                                                color = if (weeklyAccumulatedPay > 0) primaryGreen else textSecondary
                                            )
                                            Text(
                                                text = stringResource(R.string.weekly_share_label),
                                                fontSize = 10.sp,
                                                color = textSecondary
                                            )
                                        }
                                    }
                                }
                            }
                        }
                        }
                    }
                } else if (currentTab == 8) {
                    // Kesinti Ayarları Tab
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = null, tint = primaryGreen, modifier = Modifier.size(18.dp))
                        Text(
                            text = stringResource(R.string.deductions_definition_title),
                            style = MaterialTheme.typography.titleMedium,
                            color = textPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = glassBg),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = stringResource(R.string.deductions_help_text),
                            fontSize = 12.sp,
                            color = textSecondary,
                            modifier = Modifier.padding(12.dp)
                        )
                    }



                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (kesintiler.isEmpty()) {
                            Text(
                                stringResource(R.string.no_deductions_registered),
                                color = textSecondary,
                                modifier = Modifier.padding(12.dp)
                            )
                        } else {
                            kesintiler.toList().forEach { kesinti ->
                                key(kesinti.id) {
                                    KesintiRowCard(
                                        kesinti = kesinti,
                                        borderLight = borderLight,
                                        borderMuted = borderMuted,
                                        primaryGreen = primaryGreen,
                                        textPrimary = textPrimary,
                                        textSecondary = textSecondary,
                                        onDelete = {
                                            kesintiler.remove(kesinti)
                                            triggerSave()
                                        },
                                        onGlobalSaveTrigger = {
                                            triggerSave()
                                        }
                                    )
                                }
                            }
                        }
                    }
                } else if (currentTab == 9) {
                    BulutYedeklemeTabBody(
                        context = context,
                        personeller = personeller,
                        gunVerileri = gunVerileri,
                        kesintiler = kesintiler,
                        cardCommissionInput = cardCommissionInput,
                        onCommissionChange = { cardCommissionInput = it },
                        triggerSyncSave = triggerSave,
                        primaryGreen = primaryGreen,
                        textPrimary = textPrimary,
                        textSecondary = textSecondary,
                        glassBg = glassBg,
                        borderLight = borderLight,
                        borderMuted = borderMuted
                    )
                } else if (currentTab == 10) {
                    // Language Selection Tab
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Translate, contentDescription = null, tint = primaryGreen, modifier = Modifier.size(18.dp))
                            Text(
                                text = context.getString(R.string.menu_language),
                                style = MaterialTheme.typography.titleMedium,
                                color = textPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = glassBg),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Translate,
                                        contentDescription = null,
                                        tint = primaryGreen,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = context.getString(R.string.language_selection_title),
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = textPrimary
                                    )
                                }
                                
                                Column(
                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        listOf("tr" to context.getString(R.string.language_tr), "en" to context.getString(R.string.language_en)).forEach { (code, name) ->
                                            val isSelected = appLanguage == code
                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(if (isSelected) primaryGreen else Color.White.copy(alpha = 0.4f))
                                                    .border(
                                                        width = 1.dp,
                                                        color = if (isSelected) primaryGreen else borderMuted,
                                                        shape = RoundedCornerShape(8.dp)
                                                    )
                                                    .clickable {
                                                        appLanguage = code
                                                        prefs.edit().putString("selected_lang", code).apply()
                                                    }
                                                    .padding(vertical = 10.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    text = name,
                                                    fontSize = 12.sp,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                    color = if (isSelected) Color.White else textPrimary
                                                )
                                            }
                                        }
                                    }
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        listOf("ru" to context.getString(R.string.language_ru), "ar" to context.getString(R.string.language_ar)).forEach { (code, name) ->
                                            val isSelected = appLanguage == code
                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(if (isSelected) primaryGreen else Color.White.copy(alpha = 0.4f))
                                                    .border(
                                                        width = 1.dp,
                                                        color = if (isSelected) primaryGreen else borderMuted,
                                                        shape = RoundedCornerShape(8.dp)
                                                    )
                                                    .clickable {
                                                        appLanguage = code
                                                        prefs.edit().putString("selected_lang", code).apply()
                                                    }
                                                    .padding(vertical = 10.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    text = name,
                                                    fontSize = 12.sp,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                    color = if (isSelected) Color.White else textPrimary
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Action confirmation dialog to safely wipe the sheet for a new business period
        if (showResetDialog) {
            AlertDialog(
                onDismissRequest = { showResetDialog = false },
                icon = { Icon(Icons.Default.SettingsBackupRestore, contentDescription = null, tint = Color(0xFFC62828)) },
                title = { Text(stringResource(R.string.reset_alert_title), fontWeight = FontWeight.Bold) },
                text = {
                    Text(stringResource(R.string.reset_alert_desc))
                },
                confirmButton = {
                    Button(
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828)),
                        onClick = {
                            gunVerileri.forEach { gun ->
                                gun.nakit = ""
                                gun.kart = ""
                                // Clean up day indicators
                                gun.calisanlar.clear()
                            }
                            triggerSave()
                            showResetDialog = false
                        }
                    ) {
                        Text(stringResource(R.string.button_reset), fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showResetDialog = false }) {
                        Text(stringResource(R.string.button_cancel), fontWeight = FontWeight.SemiBold, color = textSecondary)
                    }
                }
            )
        }

        // Kullanım Kılavuzu Dialog
        if (showGuideDialog) {
            AlertDialog(
                onDismissRequest = { showGuideDialog = false },
                containerColor = Color(0xFF1E241A),
                iconContentColor = Color(0xFF98D882),
                titleContentColor = Color.White,
                textContentColor = Color(0xFFE3E9DC),
                icon = { Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFF98D882)) },
                title = { Text(stringResource(R.string.guide_title), fontWeight = FontWeight.Bold, color = Color.White) },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 400.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.guide_intro),
                            fontSize = 13.sp,
                            color = Color(0xFFE3E9DC)
                        )

                        HorizontalDivider(color = Color(0xFF43493E))

                        // Step 1
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(stringResource(R.string.guide_step1_title), fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF98D882))
                            Text(stringResource(R.string.guide_step1_desc), fontSize = 12.sp, color = Color(0xFFC5CBC1))
                        }

                        // Step 2
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(stringResource(R.string.guide_step2_title), fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF98D882))
                            Text(stringResource(R.string.guide_step2_desc), fontSize = 12.sp, color = Color(0xFFC5CBC1))
                        }

                        // Step 3
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(stringResource(R.string.guide_step3_title), fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF98D882))
                            Text(stringResource(R.string.guide_step3_desc), fontSize = 12.sp, color = Color(0xFFC5CBC1))
                        }

                        // Step 4
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(stringResource(R.string.guide_step4_title), fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF98D882))
                            Text(stringResource(R.string.guide_step4_desc), fontSize = 12.sp, color = Color(0xFFC5CBC1))
                        }

                        // Step 5
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(stringResource(R.string.guide_step5_title), fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF98D882))
                            Text(stringResource(R.string.guide_step5_desc), fontSize = 12.sp, color = Color(0xFFC5CBC1))
                        }

                        // Step 6
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(stringResource(R.string.guide_step6_title), fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF98D882))
                            Text(stringResource(R.string.guide_step6_desc), fontSize = 12.sp, color = Color(0xFFC5CBC1))
                        }
                    }
                },
                confirmButton = {
                    Button(
                        colors = ButtonDefaults.buttonColors(containerColor = primaryGreen, contentColor = Color.White),
                        onClick = { showGuideDialog = false }
                    ) {
                        Text(stringResource(R.string.button_got_it), fontWeight = FontWeight.Bold)
                    }
                }
            )
        }

        // İletişim & Destek Dialog
        if (showContactDialog) {
            AlertDialog(
                onDismissRequest = { showContactDialog = false },
                containerColor = Color(0xFF1E241A),
                iconContentColor = Color(0xFF98D882),
                titleContentColor = Color.White,
                textContentColor = Color(0xFFE3E9DC),
                icon = { Icon(Icons.Default.Person, contentDescription = null, tint = Color(0xFF98D882)) },
                title = { Text(stringResource(R.string.contact_support_title), fontWeight = FontWeight.Bold, color = Color.White) },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(RoundedCornerShape(50))
                                .background(Color(0xFF98D882).copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = Color(0xFF98D882),
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        Text(
                            text = stringResource(R.string.contact_support_desc),
                            fontSize = 13.sp,
                            color = Color.White,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )

                        Card(
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, Color(0xFF43493E)),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF2E3529)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = stringResource(R.string.email_address_label),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF98D882),
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = "sedatucoz@gmail.com",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }

                        Text(
                            text = stringResource(R.string.contact_support_footer),
                            fontSize = 11.sp,
                            color = Color(0xFFC5CBC1),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            lineHeight = 16.sp
                        )
                    }
                },
                confirmButton = {
                    Button(
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF386B01), contentColor = Color.White),
                        onClick = { showContactDialog = false }
                    ) {
                        Text(stringResource(R.string.button_close), fontWeight = FontWeight.Bold)
                    }
                }
            )
        }

        // Highly polished Floating Add Personnel or Kesinti dialog
        if (showDialog) {
            if (currentTab == 8) {
                var yeniAdi by remember { mutableStateOf("") }
                var yeniYuzde by remember { mutableStateOf("5.0") }

                AlertDialog(
                    onDismissRequest = { showDialog = false },
                    title = { 
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Percent, contentDescription = null, tint = primaryGreen)
                            Text(stringResource(R.string.add_deduction_dialog_title), fontWeight = FontWeight.Bold)
                        }
                    },
                    text = {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = yeniAdi,
                                onValueChange = { yeniAdi = it },
                                label = { Text(stringResource(R.string.add_deduction_label_name)) },
                                placeholder = { Text(stringResource(R.string.add_deduction_placeholder_name)) },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = primaryGreen,
                                    unfocusedBorderColor = inputBorderColor,
                                    focusedLabelColor = primaryGreen,
                                    unfocusedLabelColor = textSecondary
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = yeniYuzde, 
                                onValueChange = { yeniYuzde = it }, 
                                label = { Text(stringResource(R.string.add_deduction_label_percent)) },
                                placeholder = { Text(stringResource(R.string.add_deduction_placeholder_percent)) },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = primaryGreen,
                                    unfocusedBorderColor = inputBorderColor,
                                    focusedLabelColor = primaryGreen,
                                    unfocusedLabelColor = textSecondary
                                ),
                                shape = RoundedCornerShape(8.dp),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    },
                    confirmButton = {
                        Button(
                            colors = ButtonDefaults.buttonColors(containerColor = primaryGreen),
                            shape = RoundedCornerShape(8.dp),
                            onClick = {
                                if (yeniAdi.isNotBlank()) {
                                    val valYuzde = yeniYuzde.replace(',', '.').toDoubleOrNull() ?: 5.0
                                    val k = KesintiKategori(java.util.UUID.randomUUID().toString(), yeniAdi.trim(), valYuzde).apply {
                                        yuzdeInput = yeniYuzde
                                    }
                                    kesintiler.add(k)
                                    triggerSave()
                                    showDialog = false
                                }
                            }
                        ) {
                            Text(stringResource(R.string.button_add), fontWeight = FontWeight.Bold)
                        }
                    },
                    dismissButton = {
                        TextButton(
                            colors = ButtonDefaults.textButtonColors(contentColor = textSecondary),
                            onClick = { showDialog = false }
                        ) {
                            Text(stringResource(R.string.button_cancel), fontWeight = FontWeight.SemiBold)
                        }
                    }
                )
            } else {
                var yeniAd by remember { mutableStateOf("") }
                var yeniPuan by remember { mutableStateOf("1.0") }

                AlertDialog(
                    onDismissRequest = { showDialog = false },
                    title = { 
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Person, contentDescription = null, tint = primaryGreen)
                            Text(stringResource(R.string.add_personnel_dialog_title), fontWeight = FontWeight.Bold)
                        }
                    },
                    text = {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = yeniAd,
                                onValueChange = { yeniAd = it },
                                label = { Text(stringResource(R.string.add_personnel_label_name)) },
                                placeholder = { Text(stringResource(R.string.add_personnel_placeholder_name)) },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = primaryGreen,
                                    unfocusedBorderColor = inputBorderColor,
                                    focusedLabelColor = primaryGreen,
                                    unfocusedLabelColor = textSecondary
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = yeniPuan, 
                                onValueChange = { yeniPuan = it }, 
                                label = { Text(stringResource(R.string.add_personnel_label_rate)) },
                                placeholder = { Text(stringResource(R.string.add_personnel_placeholder_rate)) },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = primaryGreen,
                                    unfocusedBorderColor = inputBorderColor,
                                    focusedLabelColor = primaryGreen,
                                    unfocusedLabelColor = textSecondary
                                ),
                                shape = RoundedCornerShape(8.dp),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    },
                    confirmButton = {
                        Button(
                            colors = ButtonDefaults.buttonColors(containerColor = primaryGreen),
                            shape = RoundedCornerShape(8.dp),
                            onClick = {
                                if (yeniAd.isNotBlank()) {
                                    val valPuan = yeniPuan.replace(',', '.').toDoubleOrNull() ?: 1.0
                                    val p = Personel(java.util.UUID.randomUUID().toString(), yeniAd.trim(), valPuan).apply {
                                        puanInput = yeniPuan
                                    }
                                    personeller.add(p)
                                    // Enable them on all days by default
                                    gunVerileri.forEach { gun ->
                                        gun.calisanlar[p.id] = true
                                    }
                                    triggerSave()
                                    showDialog = false
                                }
                            }
                        ) {
                            Text(stringResource(R.string.button_add), fontWeight = FontWeight.Bold)
                        }
                    },
                    dismissButton = {
                        TextButton(
                            colors = ButtonDefaults.textButtonColors(contentColor = textSecondary),
                            onClick = { showDialog = false }
                        ) {
                            Text(stringResource(R.string.button_cancel), fontWeight = FontWeight.SemiBold)
                        }
                    }
                )
            }
        }
    }
}
}
}

@Composable
fun OzetSatir(
    etiket: String, 
    deger: String, 
    labelColor: Color, 
    valueColor: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 1.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(etiket, fontSize = 13.sp, color = labelColor)
        Text(deger, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = valueColor)
    }
}

@Composable
fun CustomEditField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    textStyle: TextStyle = TextStyle.Default,
    singleLine: Boolean = true,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    placeholder: String = ""
) {
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier
            .background(Color(0xFFF8FAFC), RoundedCornerShape(8.dp))
            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        textStyle = textStyle,
        singleLine = singleLine,
        keyboardOptions = keyboardOptions,
        decorationBox = { innerTextField ->
            Box(contentAlignment = Alignment.CenterStart) {
                if (value.isEmpty() && placeholder.isNotEmpty()) {
                    Text(
                        text = placeholder,
                        color = Color.Gray.copy(alpha = 0.4f),
                        style = textStyle
                    )
                }
                innerTextField()
            }
        }
    )
}

@Composable
fun PersonelRowCard(
    personel: Personel,
    calisti: Boolean,
    dynamicDailyPay: Int,
    borderLight: Color,
    borderMuted: Color,
    primaryGreen: Color,
    textPrimary: Color,
    textSecondary: Color,
    onActiveChange: (Boolean) -> Unit,
    onDelete: () -> Unit,
    onGlobalSaveTrigger: () -> Unit
) {
    val cardBorder = if (calisti) {
        BorderStroke(1.dp, borderLight)
    } else {
        BorderStroke(1.dp, borderMuted)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(if (calisti) 1f else 0.55f),
        shape = RoundedCornerShape(12.dp),
        border = cardBorder,
        colors = CardDefaults.cardColors(
            containerColor = if (calisti) Color.White else Color.White.copy(alpha = 0.5f)
        ),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(stringResource(R.string.personnel_name_label), fontSize = 11.sp, color = textSecondary, fontWeight = FontWeight.Bold)
                    CustomEditField(
                        value = personel.ad,
                        onValueChange = { 
                            personel.ad = it 
                            onGlobalSaveTrigger()
                        },
                        textStyle = TextStyle(
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = textPrimary
                        ),
                        placeholder = stringResource(R.string.personnel_name_label),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column {
                            Text(stringResource(R.string.share_coefficient_label), fontSize = 11.sp, color = textSecondary, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(2.dp))
                            CustomEditField(
                                value = personel.puanInput,
                                onValueChange = { 
                                    personel.puanInput = it
                                    onGlobalSaveTrigger()
                                },
                                textStyle = TextStyle(
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (calisti) primaryGreen else textSecondary
                                ),
                                placeholder = "1.0",
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier.width(90.dp)
                            )
                        }
                    }
                }

                Column(
                    horizontalAlignment = Alignment.End,
                    modifier = Modifier.padding(horizontal = 4.dp)
                ) {
                    Text(
                        text = "$dynamicDailyPay ₺",
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp,
                        color = if (calisti && dynamicDailyPay > 0) primaryGreen else textSecondary
                    )
                    Text(
                        text = "Günlük Pay",
                        fontSize = 9.sp,
                        color = textSecondary
                    )
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier
                        .size(36.dp)
                        .background(Color(0xFFFFEBEE), RoundedCornerShape(8.dp))
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Dünyadan Kaldır",
                        tint = Color(0xFFD32F2F),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFFF1F8E9))
                    .border(1.dp, borderMuted, RoundedCornerShape(8.dp))
                    .padding(2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (calisti) primaryGreen else Color.Transparent)
                        .clickable { onActiveChange(true) }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp),
                            tint = if (calisti) Color.White else textSecondary
                        )
                        Text(
                            text = "Çalıştı",
                            color = if (calisti) Color.White else textSecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (!calisti) Color(0xFFD32F2F) else Color.Transparent)
                        .clickable { onActiveChange(false) }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp),
                            tint = if (!calisti) Color.White else textSecondary
                        )
                        Text(
                            text = "Çalışmadı (İzinli)",
                            color = if (!calisti) Color.White else textSecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun KesintiRowCard(
    kesinti: KesintiKategori,
    borderLight: Color,
    borderMuted: Color,
    primaryGreen: Color,
    textPrimary: Color,
    textSecondary: Color,
    onDelete: () -> Unit,
    onGlobalSaveTrigger: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, borderLight),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Kesinti/Gider Adı",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = primaryGreen
                )
                
                CustomEditField(
                    value = kesinti.adi,
                    onValueChange = { 
                        kesinti.adi = it 
                        onGlobalSaveTrigger()
                    },
                    textStyle = TextStyle(
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = textPrimary
                    ),
                    placeholder = "Örn: Mutfak",
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Yüzde Oranı (%)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = primaryGreen
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        CustomEditField(
                            value = kesinti.yuzdeInput,
                            onValueChange = { 
                                kesinti.yuzdeInput = it
                                onGlobalSaveTrigger()
                            },
                            textStyle = TextStyle(
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = textPrimary
                            ),
                            placeholder = "Örn: 15.0",
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            IconButton(
                onClick = onDelete,
                modifier = Modifier
                    .size(40.dp)
                    .background(Color(0xFFFFEBEE), RoundedCornerShape(8.dp))
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Kesintiyi Sil",
                    tint = Color(0xFFD32F2F),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun BulutYedeklemeTabBody(
    context: android.content.Context,
    personeller: SnapshotStateList<Personel>,
    gunVerileri: List<GunVeri>,
    kesintiler: SnapshotStateList<KesintiKategori>,
    cardCommissionInput: String,
    onCommissionChange: (String) -> Unit,
    triggerSyncSave: () -> Unit,
    primaryGreen: Color,
    textPrimary: Color,
    textSecondary: Color,
    glassBg: Color,
    borderLight: Color,
    borderMuted: Color
) {
    val coroutineScope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("bahsis_prefs_v3", android.content.Context.MODE_PRIVATE) }
    val auth = remember {
        try {
            FirebaseAuth.getInstance()
        } catch (t: Throwable) {
            android.util.Log.e("BahsisApp", "Firebase Auth init failed dynamic fallback", t)
            null
        }
    }
    
    var currentUserState by remember { mutableStateOf(auth?.currentUser) }
    
    var emailState by remember { mutableStateOf(currentUserState?.email ?: prefs.getString("google_signed_in_email", null)) }
    var nameState by remember { mutableStateOf(currentUserState?.displayName ?: prefs.getString("google_signed_in_name", null)) }
    var photoUrlState by remember { mutableStateOf(currentUserState?.photoUrl?.toString() ?: prefs.getString("google_signed_in_photo", null)) }
    
    var lastSyncTime by remember { mutableStateOf(prefs.getLong("last_cloud_sync_time", 0L)) }
    var syncInProgress by remember { mutableStateOf(false) }
    var showConflictDialog by remember { mutableStateOf(false) }
    var pendingCloudJson by remember { mutableStateOf("") }
    var syncMessage by remember { mutableStateOf("") }
    var isErrorMsg by remember { mutableStateOf(false) }

    // GSO option definition for sign in (client side with ID token)
    val gso = remember {
        try {
            GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(context.getString(R.string.default_web_client_id))
                .requestEmail()
                .requestProfile()
                .build()
        } catch (t: Throwable) {
            android.util.Log.e("BahsisApp", "GSO Option initialization failed safely", t)
            null
        }
    }
    
    val googleSignInClient = remember(gso) {
        if (gso != null) {
            try {
                GoogleSignIn.getClient(context, gso)
            } catch (t: Throwable) {
                android.util.Log.e("BahsisApp", "GoogleSignIn.getClient creation failed safely", t)
                null
            }
        } else {
            null
        }
    }

    // Launcher for Play Services picker results
    val signInLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
            try {
                val account = task.getResult(ApiException::class.java)
                if (account != null) {
                    val idToken = account.idToken
                    if (idToken != null && auth != null) {
                        syncInProgress = true
                        syncMessage = "Firebase ile bağlantı kuruluyor..."
                        isErrorMsg = false
                        
                        val credential = GoogleAuthProvider.getCredential(idToken, null)
                        auth.signInWithCredential(credential)
                            .addOnCompleteListener { authTask ->
                                if (authTask.isSuccessful) {
                                    val user = auth.currentUser
                                    currentUserState = user
                                    val email = user?.email ?: account.email ?: ""
                                    val name = user?.displayName ?: account.displayName ?: ""
                                    val photoUrl = user?.photoUrl?.toString() ?: account.photoUrl?.toString() ?: ""
                                    
                                    // Persist locally
                                    prefs.edit()
                                        .putString("google_signed_in_email", email)
                                        .putString("google_signed_in_name", name)
                                        .putString("google_signed_in_photo", photoUrl)
                                        .apply()
                                        
                                    emailState = email
                                    nameState = name
                                    photoUrlState = photoUrl
                                    
                                    syncMessage = "Giriş başarılı! Bulut verileri aranıyor..."
                                    isErrorMsg = false
                                    
                                    // Auto-sync: download backup to see if this user has any cloud save existing
                                    val sanitized = email.replace(".", "_").replace("@", "_")
                                    coroutineScope.launch {
                                        try {
                                            val url = "https://bahsis-v3-default-rtdb.europe-west1.firebasedatabase.app/backups/$sanitized.json"
                                            val getRequest = Request.Builder().url(url).get().build()
                                            
                                            val bodyStr = withContext(Dispatchers.IO) {
                                                val response = okHttpClient.newCall(getRequest).execute()
                                                val body = if (response.isSuccessful) response.body?.string() else null
                                                response.close()
                                                body
                                            }
                                            
                                            if (bodyStr == null || bodyStr == "null" || bodyStr.isBlank()) {
                                                // No backup online, automatically save the local data to cloud as initial backup!
                                                syncMessage = "Yeni hesap tespit edildi. Yerel verileriniz otomatik olarak yedekleniyor..."
                                                val localJson = serializeStateToJson(personeller, gunVerileri, kesintiler, cardCommissionInput)
                                                val putUrl = "https://bahsis-v3-default-rtdb.europe-west1.firebasedatabase.app/backups/$sanitized.json"
                                                val mType = "application/json; charset=utf-8".toMediaType()
                                                val putReq = Request.Builder().url(putUrl).put(localJson.toRequestBody(mType)).build()
                                                
                                                val successResult = withContext(Dispatchers.IO) {
                                                    try {
                                                        val putResp = okHttpClient.newCall(putReq).execute()
                                                        val isOk = putResp.isSuccessful
                                                        putResp.close()
                                                        isOk
                                                    } catch (e: Throwable) {
                                                        false
                                                    }
                                                }
                                                if (successResult) {
                                                    prefs.edit().putLong("last_cloud_sync_time", System.currentTimeMillis()).apply()
                                                    lastSyncTime = System.currentTimeMillis()
                                                    syncMessage = context.getString(R.string.app_connected_success)
                                                } else {
                                                    syncMessage = context.getString(R.string.local_backup_failed)
                                                    isErrorMsg = true
                                                }
                                            } else {
                                                // Backup exists in cloud! Check conflict / prompt user
                                                pendingCloudJson = bodyStr
                                                // Check if local data is empty / default. If empty, auto-restore
                                                val localIsEmpty = personeller.isEmpty() || (gunVerileri.all { it.nakit.isBlank() && it.kart.isBlank() })
                                                if (localIsEmpty) {
                                                    // Auto-load without conflict prompt!
                                                    val restoredCommInput = loadStateFromJson(bodyStr, personeller, gunVerileri, kesintiler)
                                                    if (restoredCommInput != null) {
                                                        onCommissionChange(restoredCommInput)
                                                        triggerSyncSave()
                                                        syncMessage = context.getString(R.string.cloud_restore_success)
                                                        prefs.edit().putLong("last_cloud_sync_time", System.currentTimeMillis()).apply()
                                                        lastSyncTime = System.currentTimeMillis()
                                                    } else {
                                                        syncMessage = context.getString(R.string.cloud_restore_parse_failed)
                                                        isErrorMsg = true
                                                    }
                                                } else {
                                                    showConflictDialog = true
                                                    syncMessage = context.getString(R.string.cloud_backup_found)
                                                }
                                            }
                                        } catch (e: Throwable) {
                                            syncMessage = context.getString(R.string.cloud_check_failed, e.message ?: e.javaClass.simpleName)
                                            isErrorMsg = true
                                        } finally {
                                            syncInProgress = false
                                        }
                                    }
                                } else {
                                    syncInProgress = false
                                    syncMessage = context.getString(R.string.firebase_auth_failed, authTask.exception?.message ?: "")
                                    isErrorMsg = true
                                }
                            }
                    } else {
                        // Fallback local flow if ID Token is missing (unlikely, but robust)
                        val email = account.email ?: ""
                        val name = account.displayName ?: ""
                        val photoUrl = account.photoUrl?.toString() ?: ""
                        
                        prefs.edit()
                            .putString("google_signed_in_email", email)
                            .putString("google_signed_in_name", name)
                            .putString("google_signed_in_photo", photoUrl)
                            .apply()
                            
                        emailState = email
                        nameState = name
                        photoUrlState = photoUrl
                        
                        syncMessage = context.getString(R.string.local_flow_success)
                        isErrorMsg = false
                    }
                }
            } catch (e: Throwable) {
                if (e is com.google.android.gms.common.api.ApiException) {
                    val code = e.statusCode
                    val explanation = when (code) {
                        10 -> context.getString(R.string.gapi_dev_error)
                        12501 -> context.getString(R.string.gapi_canceled)
                        12500 -> context.getString(R.string.gapi_play_services_missing)
                        7 -> context.getString(R.string.gapi_network_error)
                        8 -> context.getString(R.string.gapi_internal_error)
                        else -> context.getString(R.string.gapi_unknown_error, code, e.message ?: "")
                    }
                    syncMessage = explanation
                } else {
                    syncMessage = context.getString(R.string.sign_in_error_prefix, e.message ?: e.javaClass.simpleName)
                }
                isErrorMsg = true
                syncInProgress = false
                android.util.Log.e("BahsisBackup", "Google sign in exception", e)
            }
        } else {
            syncMessage = context.getString(R.string.sign_in_canceled)
            isErrorMsg = true
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Tab Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(Icons.Default.SettingsBackupRestore, contentDescription = null, tint = primaryGreen, modifier = Modifier.size(20.dp))
            Text(
                text = "Gmail Hesap Bağlama & Yedekleme",
                style = MaterialTheme.typography.titleMedium,
                color = textPrimary,
                fontWeight = FontWeight.Bold
            )
        }

        if (emailState == null) {
            // NOT LOGGED IN VIEW WITH STYLISH HERO BOARD
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = glassBg),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Verileriniz Her Zaman Güvende!",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = primaryGreen
                    )
                    Text(
                        text = "Gmail hesabınızı bağlayarak bahşiş verilerinizi (çalışanlar, günlük girişler ve giderler) buluta eşitleyebilirsiniz. Bu sayede her yeni giriş yaptığınız yerde en son kaydınız otomatik yüklenir. Uygulamayı indirip kuran herkes kendi Gmail'i ile sisteme güvenle bağlanabilir.",
                        fontSize = 12.sp,
                        color = textSecondary,
                        lineHeight = 18.sp
                    )
                }
            }

            // Google Sign In Button
            Button(
                onClick = {
                    try {
                        val client = googleSignInClient
                        if (client != null) {
                            val signInIntent = client.signInIntent
                            signInLauncher.launch(signInIntent)
                        } else {
                            syncMessage = "Cihazınızda Google Play Hizmetleri algılanamadı veya başlatılamadı."
                            isErrorMsg = true
                        }
                    } catch (t: Throwable) {
                        syncMessage = "Giriş başlatılamadı: ${t.message ?: t.javaClass.simpleName}. Lütfen Google hizmetlerinin güncel olduğundan emin olun."
                        isErrorMsg = true
                        android.util.Log.e("BahsisBackup", "Error launching Google sign in intent", t)
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = primaryGreen),
                enabled = !syncInProgress
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Person, 
                        contentDescription = null,
                        tint = Color.White
                    )
                    Text(
                        text = "Google Hesabı ile Bağlan",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color.White
                    )
                }
            }
        } else {
            // REGISTERED / LOGGED IN SCREEN
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, borderLight),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Bağlı Google Hesabı",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = primaryGreen,
                        letterSpacing = 0.5.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // User Profile Circle (Uses custom initials fallback for maximum stability and offline performance)
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(50))
                                .background(primaryGreen.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = (nameState?.take(2)?.uppercase() ?: "G"),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = primaryGreen
                            )
                        }

                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Text(
                                text = nameState ?: "Kullanıcı",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = textPrimary
                            )
                            Text(
                                text = emailState ?: "",
                                fontSize = 12.sp,
                                color = textSecondary
                            )
                        }
                        
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFE8F5E9))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.active_status_label),
                                color = Color(0xFF2E7D32),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    HorizontalDivider(color = borderMuted.copy(alpha = 0.5f))

                    // Sync details
                    val dtFormatted = if (lastSyncTime > 0) {
                        val sdf = java.text.SimpleDateFormat("dd.MM.yyyy HH:mm:ss", java.util.Locale.getDefault())
                        sdf.format(java.util.Date(lastSyncTime))
                    } else {
                        stringResource(R.string.no_sync_yet_label)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(stringResource(R.string.last_sync_title), fontSize = 12.sp, color = textSecondary)
                        Text(dtFormatted, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = textPrimary)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(stringResource(R.string.backup_status_title), fontSize = 12.sp, color = textSecondary, modifier = Modifier.weight(1f))
                        Text(
                            text = stringResource(R.string.automatic_saving_desc),
                            fontSize = 11.sp, 
                            fontWeight = FontWeight.Bold, 
                            color = primaryGreen,
                            textAlign = androidx.compose.ui.text.style.TextAlign.End,
                            modifier = Modifier.weight(2f)
                        )
                    }
                }
            }

            // Sync Manual actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // FORCE SAVE TO CLOUD
                Button(
                    onClick = {
                        val sanitized = emailState?.replace(".", "_")?.replace("@", "_")
                        if (sanitized != null) {
                            coroutineScope.launch {
                                syncInProgress = true
                                syncMessage = context.getString(R.string.sync_sending_message)
                                isErrorMsg = false
                                try {
                                    val localJson = serializeStateToJson(personeller, gunVerileri, kesintiler, cardCommissionInput)
                                    val putUrl = "https://bahsis-v3-default-rtdb.europe-west1.firebasedatabase.app/backups/$sanitized.json"
                                    val mType = "application/json; charset=utf-8".toMediaType()
                                    val putReq = Request.Builder().url(putUrl).put(localJson.toRequestBody(mType)).build()
                                    
                                    val success = withContext(Dispatchers.IO) {
                                        val response = okHttpClient.newCall(putReq).execute()
                                        val isOk = response.isSuccessful
                                        response.close()
                                        isOk
                                    }
                                    if (success) {
                                        prefs.edit().putLong("last_cloud_sync_time", System.currentTimeMillis()).apply()
                                        lastSyncTime = System.currentTimeMillis()
                                        syncMessage = context.getString(R.string.sync_success_message)
                                    } else {
                                        syncMessage = context.getString(R.string.sync_failed_server)
                                        isErrorMsg = true
                                    }
                                } catch (e: Throwable) {
                                    syncMessage = context.getString(R.string.sync_error, e.message ?: e.javaClass.simpleName)
                                    isErrorMsg = true
                                } finally {
                                    syncInProgress = false
                                }
                            }
                        }
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = primaryGreen),
                    enabled = !syncInProgress
                ) {
                    Text(stringResource(R.string.force_sync_button), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                // FORCE DOWNLOAD FROM CLOUD
                OutlinedButton(
                    onClick = {
                        val sanitized = emailState?.replace(".", "_")?.replace("@", "_")
                        if (sanitized != null) {
                            coroutineScope.launch {
                                syncInProgress = true
                                syncMessage = context.getString(R.string.sync_downloading)
                                isErrorMsg = false
                                try {
                                    val url = "https://bahsis-v3-default-rtdb.europe-west1.firebasedatabase.app/backups/$sanitized.json"
                                    val getReq = Request.Builder().url(url).get().build()
                                    
                                    val bodyStr = withContext(Dispatchers.IO) {
                                        val response = okHttpClient.newCall(getReq).execute()
                                        val body = if (response.isSuccessful) response.body?.string() else null
                                        response.close()
                                        body
                                    }
                                    if (bodyStr == null || bodyStr == "null" || bodyStr.isBlank()) {
                                        syncMessage = context.getString(R.string.sync_no_backup)
                                        isErrorMsg = true
                                    } else {
                                        pendingCloudJson = bodyStr
                                        showConflictDialog = true
                                        syncMessage = context.getString(R.string.sync_read_success)
                                    }
                                } catch (e: Throwable) {
                                    syncMessage = context.getString(R.string.sync_restore_failed, e.message ?: e.javaClass.simpleName)
                                    isErrorMsg = true
                                } finally {
                                    syncInProgress = false
                                }
                            }
                        }
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, primaryGreen),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = primaryGreen),
                    enabled = !syncInProgress
                ) {
                    Text(stringResource(R.string.force_download_button), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Clean SIGN OUT BUTTON
            OutlinedButton(
                onClick = {
                    try {
                        FirebaseAuth.getInstance().signOut()
                    } catch (t: Throwable) {
                        t.printStackTrace()
                    }
                    
                    val onClearLocalAuth = {
                        prefs.edit()
                            .remove("google_signed_in_email")
                            .remove("google_signed_in_name")
                            .remove("google_signed_in_photo")
                            .remove("last_cloud_sync_time")
                            .apply()
                            
                        emailState = null
                        nameState = null
                        photoUrlState = null
                        lastSyncTime = 0L
                        syncMessage = context.getString(R.string.disconnected_message)
                        isErrorMsg = false
                        currentUserState = null
                    }
                    
                    val client = googleSignInClient
                    if (client != null) {
                        try {
                            client.signOut().addOnCompleteListener {
                                onClearLocalAuth()
                            }
                        } catch (t: Throwable) {
                            onClearLocalAuth()
                        }
                    } else {
                        onClearLocalAuth()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, Color(0xFFC62828).copy(alpha = 0.5f)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFC62828))
            ) {
                Text(stringResource(R.string.disconnect_gmail_button), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Action Status Banner
        if (syncMessage.isNotEmpty() || syncInProgress) {
            val bannerColor = if (syncInProgress) {
                primaryGreen.copy(alpha = 0.1f)
            } else if (isErrorMsg) {
                Color(0xFFFFEBEE)
            } else {
                primaryGreen.copy(alpha = 0.1f)
            }

            val textTint = if (syncInProgress) {
                primaryGreen
            } else if (isErrorMsg) {
                Color(0xFFC62828)
            } else {
                primaryGreen
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(bannerColor)
                    .padding(12.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (syncInProgress) {
                        CircularProgressIndicator(
                            color = primaryGreen,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(16.dp)
                        )
                    } else {
                        Icon(
                            imageVector = if (isErrorMsg) Icons.Default.Close else Icons.Default.Check,
                            contentDescription = null,
                            tint = textTint,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(
                        text = syncMessage,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = textTint
                    )
                }
            }
        }


    }

    // Backup Confirmation choice dialog
    if (showConflictDialog) {
        AlertDialog(
            onDismissRequest = { showConflictDialog = false },
            icon = { Icon(Icons.Default.SettingsBackupRestore, contentDescription = null, tint = primaryGreen) },
            title = { Text(stringResource(R.string.conflict_title), fontWeight = FontWeight.Bold) },
            text = {
                Text(stringResource(R.string.conflict_desc))
            },
            confirmButton = {
                Button(
                    colors = ButtonDefaults.buttonColors(containerColor = primaryGreen),
                    onClick = {
                        coroutineScope.launch {
                            val restoredCommInput = loadStateFromJson(pendingCloudJson, personeller, gunVerileri, kesintiler)
                            if (restoredCommInput != null) {
                                onCommissionChange(restoredCommInput)
                                triggerSyncSave()
                                syncMessage = context.getString(R.string.backup_overrule_restore_success)
                                prefs.edit().putLong("last_cloud_sync_time", System.currentTimeMillis()).apply()
                                lastSyncTime = System.currentTimeMillis()
                            } else {
                                syncMessage = context.getString(R.string.backup_overrule_restore_failed)
                                isErrorMsg = true
                            }
                        }
                        showConflictDialog = false
                    }
                ) {
                    Text(stringResource(R.string.load_cloud_to_device), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        // Or override online content with device state!
                        val sanitized = emailState?.replace(".", "_")?.replace("@", "_")
                        if (sanitized != null) {
                            coroutineScope.launch {
                                syncInProgress = true
                                syncMessage = context.getString(R.string.overruled_sync_sending)
                                isErrorMsg = false
                                try {
                                    val localJson = serializeStateToJson(personeller, gunVerileri, kesintiler, cardCommissionInput)
                                    val putUrl = "https://bahsis-v3-default-rtdb.europe-west1.firebasedatabase.app/backups/$sanitized.json"
                                    val mType = "application/json; charset=utf-8".toMediaType()
                                    val putReq = Request.Builder().url(putUrl).put(localJson.toRequestBody(mType)).build()
                                    
                                    val success = withContext(Dispatchers.IO) {
                                        val response = okHttpClient.newCall(putReq).execute()
                                        val isOk = response.isSuccessful
                                        response.close()
                                        isOk
                                    }
                                    if (success) {
                                        prefs.edit().putLong("last_cloud_sync_time", System.currentTimeMillis()).apply()
                                        lastSyncTime = System.currentTimeMillis()
                                        syncMessage = context.getString(R.string.device_overrule_success)
                                    } else {
                                        syncMessage = context.getString(R.string.device_overrule_failed_server)
                                        isErrorMsg = true
                                    }
                                } catch (e: Throwable) {
                                    syncMessage = context.getString(R.string.device_overrule_failed_exception, e.message ?: e.javaClass.simpleName)
                                    isErrorMsg = true
                                } finally {
                                    syncInProgress = false
                                }
                            }
                        }
                        showConflictDialog = false
                    }
                ) {
                    Text(stringResource(R.string.save_device_to_cloud), fontWeight = FontWeight.SemiBold, color = primaryGreen)
                }
            }
        )
    }
}


